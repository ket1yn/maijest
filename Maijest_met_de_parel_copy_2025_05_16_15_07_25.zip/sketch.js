function setup() {
  createCanvas(400, 600);
  background(20, 20, 30); // Cor de fundo escura, inspirada no fundo da pintura
}

function draw() {
  // Desenho do rosto da menina
  fill(255, 220, 185); // Tom de pele clara
  noStroke();
  ellipse(200, 240, 120, 150); // Cabeça da menina
  
  // Cabelos
  fill(90, 60, 30); // Cor do cabelo, castanho
  beginShape();
  vertex(140, 160);
  bezierVertex(120, 160, 140, 80, 200, 100);
  bezierVertex(260, 80, 280, 160, 240, 160);
  endShape(CLOSE);

  // Olhos
  fill(0); // Cor dos olhos
  ellipse(180, 230, 20, 15); // Olho esquerdo
  ellipse(220, 230, 20, 15); // Olho direito
  
  // Boca
  stroke(120, 50, 50);
  strokeWeight(2);
  noFill();
  arc(200, 260, 40, 20, 0, PI); // Boca sutil

  // Pérola (brinco)
  fill(255); // Cor da pérola
  ellipse(260, 280, 30, 30); // A pérola

  // Detalhes da capa
  fill(70, 30, 90); // Cor da capa, mais escura
  beginShape();
  vertex(140, 320);
  vertex(260, 320);
  vertex(240, 470);
  vertex(160, 470);
  endShape(CLOSE);
}
